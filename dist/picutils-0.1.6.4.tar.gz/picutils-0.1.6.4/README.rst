
picutils
--------

|PyPI version|

json2df is a library does batch processing pictures
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

github: https://github.com/shichaoji/picutils
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-  If you would like to run a image hosting website, it is handy to
   process a large number of images

I have used the library processed almost 1 million photos for my other project face similarity searching & indexing, landmark detecting
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

http://iridescent.date/
~~~~~~~~~~~~~~~~~~~~~~~

.. |PyPI version| image:: https://badge.fury.io/py/picutils.svg
   :target: https://badge.fury.io/py/picutils

installation
~~~~~~~~~~~~

``$ pip install pictutils``

usage example
~~~~~~~~~~~~~

Batch reducing pics size to about 200kb each, if you have many HD pics saved in a folder, run the library will batch coverting pics in the folder to .jpg and then resizing all pics till 100-200 kb each.R
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-  Run $ python -m picutils.process\_pics , and then pass the images
   folder's name, in the directory where that folder resides

Making index.html webbrowser file for a folder of pics for overall viewing, or hosting in a webpage
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-  Run $ python -m picutils.html\_index , and then pass the images
   folder's name, in the directory where that folder resides

   -  the program will make a sub-thumbnail folder, so even if image
      sizes in the folder are very large, the small view pics in the
      index html will load instantly, for the purpose of hosting picture
      website when visitors has slow internet
   -  Thanks to myphotopack.com for those pretty pictures

Making a viewer.html webbrowser file for a folder of pics for single viewing, e.g. hosting a manga Website
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-  Run $ python -m picutils.html\_viewer , and then pass the images
   folder's name, in the directory where that folder resides

   -  click right side of the photo will view next, while clicking left
      side turns to previous photo
