# -*- coding:utf-8 -*-
from .base import move_out




if __name__=='__main__':
    print('run move_out()')
    move_out()
