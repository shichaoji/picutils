# -*- coding:utf-8 -*-
from .base import processPics




if __name__=='__main__':
    print('run processPics()')
    processPics()
