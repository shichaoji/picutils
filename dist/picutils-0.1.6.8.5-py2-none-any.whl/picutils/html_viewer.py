# -*- coding:utf-8 -*-
from .base import html_viewer




if __name__=='__main__':
    print('run html_viewer()')
    html_viewer()
