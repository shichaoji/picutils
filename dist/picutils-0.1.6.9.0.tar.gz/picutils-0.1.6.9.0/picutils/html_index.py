# -*- coding:utf-8 -*-
from .base import html_index




if __name__=='__main__':
    print('run html_index()')
    html_index()
