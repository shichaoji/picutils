#!/usr/bin/python
#-*- coding:utf-8 -*-

from .base import processPics

__version__ = '0.1'
__license__ = 'MIT'

__all__ = ['processPics']


