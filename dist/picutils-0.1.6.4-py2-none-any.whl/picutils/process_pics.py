# -*- coding:utf-8 -*-
from .base import process_pics




if __name__=='__main__':
    print('run process_pics()')
    process_pics()
