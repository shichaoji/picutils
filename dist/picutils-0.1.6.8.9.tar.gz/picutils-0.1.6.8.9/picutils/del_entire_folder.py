# -*- coding:utf-8 -*-
from .base import del_entire_folder




if __name__=='__main__':
    print('run del_entire_folder()')
    del_entire_folder()
